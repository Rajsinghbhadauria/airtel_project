package com.example.airtel_project.service;

import com.example.airtel_project.entity.User;

public interface UserService {

    User adduser(User user);

    User getUserById(Integer id);
}
