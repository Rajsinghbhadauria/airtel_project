package com.example.airtel_project.controller;

import com.example.airtel_project.entity.User;
import com.example.airtel_project.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService userService;
    @PostMapping("/")
    public ResponseEntity<User> addUser(@RequestBody User user){
       return ResponseEntity.ok(userService.adduser(user));
    }
    @GetMapping("/{id}")
    public User getByUserId(@PathVariable Integer id){
       return userService.getUserById(id);
    }
}
