package com.example.airtel_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirtelProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
